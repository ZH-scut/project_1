import pandas as pd 
import numpy as np
import time
import sklearn
#读取train文件
print('Read the dataset and set the x_train，y_train,x_test,y_test')

df = pd.read_csv(r'C:\Users\ZHUHU\Desktop\project_code\new_data.csv', header = None)
df= df.drop([0,1,2,3], axis = 1)
dataset = df.values

x_train = []
for i  in range(30904):
    x_temp = dataset[i+1][1:16]
    x_train.append(x_temp)
x_train= np.array(x_train)

y_train = []
for i in range(30904):
    y_temp = dataset[i+1][0]
    y_train.append(y_temp)
y_train = np.array(y_train)


tf = pd.read_csv(r'C:\Users\ZHUHU\Desktop\project_code\test_set.csv', header = None)
tf= tf.drop([0,1,2,3], axis = 1)
testdata = tf.values

x_test = []
for i in range(20586):
    tes_temp = testdata[i+1][1:16]
    x_test.append(tes_temp)
x_test = np.array(x_test)
#print(x_test)
 
y_test = []
for i in range(20586):
    tes_temp = testdata[i+1][0]
    y_test.append(tes_temp)
y_test = np.array(y_test)
#print(y_test)

print('Now begin to train the four classifiers: ')

print('Decision Tree:')
#Decision Tree
startdt = time.time()
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier

dt= DecisionTreeClassifier(max_depth=4)
dt.fit(x_train, y_train)
enddt = time.time()
#paras_dt = dt.get_params()
accuracy_dt = dt.score(x_test, y_test)
#print(paras_dt)
print('The accuracy of DT is:',accuracy_dt)
print('Training time(DT): %s Seconds' %(enddt-startdt))

print('SVM')
#SVM
startsvm = time.time()
from sklearn.svm import SVC
svm = SVC(kernel ='linear',gamma = 'auto' )
svm.fit(x_train,y_train)
endsvm = time.time()
#paras_svm = svm.get_params()
accuracy_svm = svm.score(x_test,y_test)
#print(paras_svm)
print('The accuracy of SVM is:', accuracy_svm)
print('Training time(SVM): %s Seconds' %(endsvm-startsvm))

print('K-NN')
#K-NN
startknn = time.time()
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=11)
knn.fit(x_train, y_train)
endknn = time.time()
#paras_knn = knn.get_params()
accuracy_knn = knn.score(x_test,y_test)
#print(paras_knn)
print('The accuracy of K-NN :', accuracy_knn)
print('Training time(K-NN): %s Seconds' %(endknn-startknn))


print('MLP')
#MLP
startmlp = time.time()
from sklearn.neural_network import MLPClassifier
mlp = MLPClassifier(activation='identity',max_iter=10000,solver='lbfgs',
                    alpha=0.0001,
                    learning_rate='constant',learning_rate_init=0.001,
                    momentum=0.9)
mlp.fit(x_train, y_train)
endmlp = time.time()
#paras_mlp = mlp.get_params()
accuracy_mlp = mlp.score(x_test,y_test)
#print(paras_mlp)
print('The accuracy of MLP: ', accuracy_mlp)
print('Training time(MLP): %s Seconds' %(endmlp-startmlp))
